package ast.base;

import java.io.Serializable;

import ast.exception.EvaluationException;
import ast.interfaces.IVisitor;
import fr.sorbonne_u.cps.sensor_network.interfaces.PositionI;
import fr.sorbonne_u.cps.sensor_network.requests.interfaces.ExecutionStateI;

public abstract class Base implements Serializable {
	private static final long serialVersionUID = 1L;
	protected PositionI position;
	
	Base(PositionI pos){
		position = pos;
	}

    public abstract Object eval(IVisitor visitor, ExecutionStateI e) throws EvaluationException;
}
