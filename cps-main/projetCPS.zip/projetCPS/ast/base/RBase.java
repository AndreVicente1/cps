package ast.base;

import ast.exception.EvaluationException;
import ast.interfaces.IVisitor;
import fr.sorbonne_u.cps.sensor_network.interfaces.PositionI;
import fr.sorbonne_u.cps.sensor_network.requests.interfaces.ExecutionStateI;

public class RBase extends Base{
	
	private static final long serialVersionUID = 1L;

	public RBase(PositionI pos) {
		super(pos);
	}

	public PositionI getPos() {
		return position;
	}
	
    public Object eval(IVisitor visitor, ExecutionStateI e) throws EvaluationException {
        return visitor.visit(this, e);
    }
}
