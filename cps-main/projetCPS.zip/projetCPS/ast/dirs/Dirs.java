package ast.dirs;

import java.io.Serializable;

import ast.exception.EvaluationException;
import ast.interfaces.IVisitor;
import fr.sorbonne_u.cps.sensor_network.interfaces.Direction;
import fr.sorbonne_u.cps.sensor_network.requests.interfaces.ExecutionStateI;

public abstract class Dirs implements Serializable{
    private static final long serialVersionUID = 1L;
	public abstract Object eval(IVisitor visitor, ExecutionStateI e) throws EvaluationException;
    public Direction getDir() {
        return null;
    }
}
