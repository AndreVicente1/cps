package ast.exception;

public class EvaluationException extends Exception{
    private static final long serialVersionUID = 1L;

	public EvaluationException(String msg){
        super(msg);
    }
}